package CircuitBreaker.phase2;

import java.time.Clock;
import java.time.Duration;
import java.time.Instant;
import java.util.ArrayDeque;
import java.util.Deque;
import java.util.Map;
import java.util.Random;
import java.util.concurrent.ConcurrentHashMap;
import CircuitBreaker.CircuitOpenException;
import CircuitBreaker.Response;


class WebClient2 {

    /*
     * Circuit-breaker policy:
     *
     * - Open after 3 failures within a rolling 20-second window.
     * - Once open, wait 10 seconds before allowing one recovery probe.
    */
    private static final int FAILURE_THRESHOLD = 3;
    private static final Duration FAILURE_WINDOW = Duration.ofSeconds(20);
    private static final Duration COOLDOWN = Duration.ofSeconds(10);


    /*
     * Inject the source of time so rolling-window and cooldown behaviour can be
     * tested deterministically without relying on real time or Thread.sleep().
    */
    private final Clock clock;


     /*
     * Keep one circuit per downstream service so failures remain isolated.
     *
     * ConcurrentHashMap is required here because it allows multiple threads to
     * look up/create circuits concurrently. It protects the map itself; each
     * service circuit still synchronizes its own mutable breaker state.
     *
     * Per-circuit locking avoids one slow or busy service serializing state
     * changes for every other downstream service.
     */
    private final Map<String, ServiceCircuit> circuits = new ConcurrentHashMap<>();


    public WebClient2() {
        this(Clock.systemUTC());
    }

    public WebClient2(Clock clock) {
        this.clock = clock;
    }


    public Response execute(String service) {
        if (service == null || service.isBlank()) {
            throw new IllegalArgumentException("service name must be provided");
        }


        ServiceCircuit circuit = circuits.computeIfAbsent(service, ignored -> new ServiceCircuit());


         /*
         * Admission and state transitions are synchronized inside ServiceCircuit,
         * but the downstream call is deliberately outside that lock. Holding a
         * lock across network I/O would serialize requests to the same service and
         * make every caller wait for the slowest remote request.
         */
        boolean recoveryProbe = false;

        Instant now = clock.instant();
        Admission admission = circuit.admit(now);

        if (admission == Admission.REJECTED) {
             throw new CircuitOpenException(service);
        }

        recoveryProbe = admission == Admission.RECOVERY_PROBE;

        Response response = call();


         /*
         * Use the completion time, not the admission time, when recording a
         * failure because the remote call may have taken significant time.
         */
        Instant outcomeTime = clock.instant();

        if (response.getStatus() == 200) {
            circuit.handleSuccessfulResponse(recoveryProbe);
        }

        if (response.getStatus() == 500) {
            circuit.handleFailure(recoveryProbe, outcomeTime);
        }

        /*
         * The request that reaches the threshold still receives the downstream
         * response. Opening the circuit affects subsequent requests.
         */
        return response;
    }

     /*
     * HALF_OPEN is explicit because concurrency introduces a state that cannot
     * safely be represented by only "open/closed": exactly one request must be
     * allowed to test recovery while all competing requests fail fast.
     */
    private enum CircuitState {
        CLOSED,
        OPEN,
        HALF_OPEN
    }

    private enum Admission {
        NORMAL,
        RECOVERY_PROBE,
        REJECTED
    }

    /*
     * Holds the independent circuit-breaker state for one downstream service.
    */
    private static final class ServiceCircuit {

        /*
         * ArrayDeque gives a lightweight Deque with O(1) amortized append.
         *
         * Unlike Stage 1, concurrent requests can finish in a different order
         * from the order in which they started. The timestamps therefore cannot
         * be assumed to remain chronologically ordered, so cleanup must inspect
         * the retained entries rather than only removing from the front.
         */
        private final Deque<Instant> failures = new ArrayDeque<>();

        // All services begin CLOSED.
        private CircuitState state = CircuitState.CLOSED;
        private Instant openedAt;


        /*
         * Synchronize the whole admission decision so checking OPEN, verifying
         * the cooldown, and changing OPEN -> HALF_OPEN happen atomically.
         *
         * Otherwise multiple threads could all observe an expired cooldown and
         * become recovery probes at the same time.
         */
        private synchronized Admission admit(Instant now) {
            pruneExpiredFailures(now);

            if (state == CircuitState.OPEN) {

                Instant recoveryAllowedAt = openedAt.plus(COOLDOWN);

                // Cooldown has not finished. so fail fast
                if (now.isBefore(recoveryAllowedAt)) {
                    return Admission.REJECTED;
                }

                 /*
                 * Because this transition occurs while holding this circuit's
                 * lock, exactly one thread can claim the recovery probe.
                 */
                state = CircuitState.HALF_OPEN;
                return Admission.RECOVERY_PROBE;
            }

            else if (state == CircuitState.HALF_OPEN) {
                return Admission.REJECTED;
            }

            return Admission.NORMAL;
        }


        /*
         * Synchronize because a successful recovery probe resets shared circuit
         * state. The reset must not race with another thread admitting a request
         * or recording a failure.
         */
        private synchronized void handleSuccessfulResponse(boolean recoveryProbe) {

            /*
             * A normal 200 does not erase earlier failures because the policy is
             * based on failures inside a rolling window, not consecutive failures.
             *
             * A successful HALF_OPEN probe is different: it is explicit evidence
             * of recovery, so the breaker can safely return to a clean CLOSED state.
             */
            if (recoveryProbe) {
                reset();
                return;
            }
        }


        /*
         * Synchronize because pruning failures, recording the new failure,
         * checking the threshold, and possibly changing circuit state must happen
         * as one atomic update.
         *
         * Concurrent requests must not modify the failure history or breaker
         * state while this decision is being made.
         */
        private synchronized void handleFailure(boolean recoveryProbe, Instant outcomeTime) {

            if (recoveryProbe) {

                 /*
                 * A failed recovery probe proves the downstream is still unhealthy,
                 * so reopen immediately and restart the cooldown from this failure.
                 */
                block(outcomeTime);
                failures.clear();

                recordFailure(outcomeTime);

                return;
            }


            pruneExpiredFailures(outcomeTime);
            recordFailure(outcomeTime);


             /*
             * Another in-flight request may have changed the state while this
             * request was performing network I/O. Only a still-CLOSED circuit may
             * transition to OPEN because of the normal failure threshold.
             */
            if (state == CircuitState.CLOSED && hasReachedFailureThreshold()) {
                block(outcomeTime);
            }
        }

        private void reset() {
            failures.clear();
            openedAt = null;
            state = CircuitState.CLOSED;
        }


        private void recordFailure(Instant failureTime) {
            failures.addLast(failureTime);
        }


        private boolean hasReachedFailureThreshold() {
            return failures.size() >= FAILURE_THRESHOLD;
        }


        private void block(Instant failureTime) {
            state = CircuitState.OPEN;
            openedAt = failureTime;
        }


        private void pruneExpiredFailures(Instant now) {

            Instant cutoff = now.minus(FAILURE_WINDOW);

            /*
             * Concurrent requests can complete out of order, so insertion order
             * does not guarantee timestamp order. removeIf() is O(n), but it does
             * not depend on ordering and the retained failure set is expected to
             * stay small around the threshold, making that trade-off reasonable.
             *
             * !isAfter(cutoff) intentionally expires failures exactly 20 seconds old.
             */
            failures.removeIf(t -> !t.isAfter(cutoff));
        }
    }


    public Response call() {
        Random random = new Random();

        int rand = random.nextInt(2);

        Response response = new Response();

        int status = rand == 0 ? 200 : 500;

        response.setStatus(status);

        return response;
    }


    /*
     * This loop demonstrates the time-based breaker behaviour only; it is not a
     * concurrency test because all calls still execute on the main thread.
     */
    public static void main(String[] args) throws InterruptedException {

        WebClient2 webClient = new WebClient2();

        Random random = new Random();

        for (int i = 0; i < 30; i++) {

            int rand = random.nextInt(2);
            String service = (rand == 0) ? "ServiceB" : "ServiceC";

            try {
                Response response = webClient.execute(service);
                System.out.println(Instant.now() + " -> " + service + " : " + response);
            } catch (CircuitOpenException e) {
                System.out.println(Instant.now() + " -> " + service + " : " + e.getMessage());
            }

            Thread.sleep(2000);
        }
    }
}