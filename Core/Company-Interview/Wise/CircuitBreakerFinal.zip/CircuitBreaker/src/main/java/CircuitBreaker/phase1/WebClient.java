package CircuitBreaker.phase1;
import java.time.Clock;
import java.time.Duration;
import java.time.Instant;
import java.util.ArrayDeque;
import java.util.Deque;
import java.util.HashMap;
import java.util.Map;
import java.util.Objects;
import java.util.Random;
import CircuitBreaker.CircuitOpenException;
import CircuitBreaker.Request;
import CircuitBreaker.Response;

class WebClient {

    /*
     * Circuit-breaker policy:
     *
     * - Open after 3 failures within a rolling 20-second window.
     * - Once open, wait 10 seconds before allowing a recovery attempt.
     */
    private static final int FAILURE_THRESHOLD = 3;
    private static final Duration FAILURE_WINDOW = Duration.ofSeconds(20);
    private static final Duration COOLDOWN = Duration.ofSeconds(10);


     /*
     * Keep circuit state isolated per downstream service so failures in one
     * service do not affect another.
     *
     * HashMap is sufficient because Stage 1 assumes single-threaded access.
     */
    private final Map<String, ServiceCircuit> circuits = new HashMap<>();

     /*
     * Inject the source of time so rolling-window and cooldown behaviour
     * can be tested deterministically without relying on real time or sleep().
     *
     * Instant still represents timestamps; Clock controls where "now" comes from.
     */
    private final Clock clock;

    public WebClient(Clock clock) {
        this.clock = Objects.requireNonNull(clock, "clock is required");
    }

    public WebClient() {
         this(Clock.systemUTC());
    }

    // public Response execute(String service) {
    public Response execute(Request request) {

        if (request == null) {
            throw new IllegalArgumentException("request is required");
        }

        String service = request.getService();

        if (service == null || service.isBlank()) {
            throw new IllegalArgumentException(
                "service name not provided"
            );
        }

        ServiceCircuit circuit = circuits.computeIfAbsent(service, k -> new ServiceCircuit());

        /*
         * Capture the current time to:
         * - remove failures older than 20 seconds
         * - determine whether the cooldown has finished
         */
        Instant now = clock.instant();

        circuit.pruneExpiredFailures(now);

        // determine whether this service is currently blocked
        // blockedAt == null -> normal operation
        // blockedAt != null -> service has previously opened its circuit
        boolean recoveryAttempt = false;

        if (circuit.isBlocked()) {

            /*
             * Recovery becomes eligible exactly at unblockAt.
             *
             * now < unblockAt  -> still blocked
             * now >= unblockAt -> recovery may be attempted
             *
             * Using isBefore() gives us that exact boundary behaviour.
             */
            Instant unblockAt = circuit.getUnblockedAt();
            if (now.isBefore(unblockAt)) {

                // critical: fail fast, do not call call()
                throw new CircuitOpenException(service);

                // Response response = new Response();
                // response.setStatus(503);
                // return response;
            }

            /*
             * Do not reset the breaker simply because the cooldown elapsed.
             * Time passing does not prove the downstream service recovered.
             *
             * Keep the circuit logically open until this permitted request
             * actually succeeds.
            */
            recoveryAttempt = true;
        }


        Response response = null;
        try {
            response = call();
        } catch (Exception e) {
            /*
             * Transport failures such as timeouts or connection errors count
             * toward the breaker just like qualifying failure responses.
             *
             * Re-throw afterward because the caller still needs to know that
             * the downstream operation itself failed.
             */
            handleFailure(circuit, recoveryAttempt);
            throw e;
        }



        if (response.getStatus() == 200) {
            handleSuccessfulResponse(circuit, recoveryAttempt);
            return response;
        }


        if (response.getStatus() == 500) {
          handleFailure(circuit, recoveryAttempt);
        }

        /*
         * The request that reaches the failure threshold still receives the
         * downstream response. Opening the circuit affects subsequent calls.
        */
        return response;
    }

    private void handleSuccessfulResponse(ServiceCircuit circuit, boolean recoveryAttempt) {
           /*
            * A normal 200 does NOT erase earlier failures.
            *
            * The threshold is based on the number of failures inside a rolling
            * time window, not on consecutive failures.
            *
            * Example:
            *
            *      500 -> failure #1
            *      200
            *      500 -> failure #2
            *      200
            *      500 -> failure #3
            *
            * If all three failures occurred within 20 seconds, the circuit should
            * still open. Clearing the history after every 200 would accidentally
            * turn the policy into "3 consecutive failures", which is a different
            * circuit-breaker rule.
            *
            * A successful RECOVERY attempt is different. The circuit was already
            * open and deliberately allowed one request through after cooldown.
            * That successful probe is evidence that the downstream service has
            * recovered, so the previous failure history can now be discarded.
            */
            if (recoveryAttempt) {
                circuit.reset();
            }

    }

    private void handleFailure(ServiceCircuit circuit, boolean recoveryAttempt) {

             /*
                * Re-read the clock after call() because the downstream request may
                * have taken time. Using the pre-call timestamp could record the failure
                * earlier than it actually occurred and distort the rolling window.
            */
            Instant failureTime = clock.instant();

            circuit.pruneExpiredFailures(failureTime);
            circuit.recordFailure(failureTime);

             /*
                * A failed recovery attempt reopens immediately because the service
                * has just demonstrated that it is still unhealthy.
                *
                * Normal traffic opens the circuit only after reaching the configured
                * failure threshold.
            */
            if (recoveryAttempt || circuit.hasReachedFailureThreshold()) {
                circuit.block(failureTime);
            }
    }

    /*
     * Holds the independent circuit-breaker state for one downstream service.
     */
    private static final class ServiceCircuit {

        /*
         * Failure timestamps are stored oldest -> newest.
         *
         * ArrayDeque fits the rolling-window access pattern:
         *
         *      front                         back
         *        ↓                             ↓
         *   [oldest] [failure] [failure] [newest]
         *
         * New failures are appended at the back while expired failures are
         * removed from the front. We therefore avoid scanning or shifting the
         * entire collection whenever the rolling window advances.
         *
         * Complexity:
         *
         * - addLast():      O(1) amortized
         * - peekFirst():    O(1)
         * - removeFirst():  O(1)
         *
         * pruneExpiredFailures() may remove k timestamps during one call,
         * making that individual call O(k). However, each timestamp is inserted
         * once and removed once, so pruning is O(1) amortized per recorded
         * failure over time.
         *
         * Space complexity is O(f), where f is the number of failure timestamps
         * currently retained inside the rolling window.
         *
         * This assumes single-threaded access, which preserves timestamp
         * ordering. Concurrent state transitions would require synchronization.
         */
        private final Deque<Instant> failures = new ArrayDeque<>();



        /*
         * null -> circuit is closed
         * non-null -> time at which the circuit was opened
         */
        private Instant blockedAt;

        private boolean isBlocked() {
            return blockedAt != null;
        }

        private Instant getUnblockedAt() {
            return blockedAt.plus(COOLDOWN);
        }

        private void reset() {
            failures.clear();
            blockedAt = null;
        }

        private void recordFailure(Instant failureTime) {
            failures.addLast(failureTime);
        }

        private boolean hasReachedFailureThreshold() {
            return failures.size() >= FAILURE_THRESHOLD;
        }

        private void block(Instant failureTime) {
            blockedAt = failureTime;
        }


        private void pruneExpiredFailures(Instant now) {

            Instant cutoff = now.minus(FAILURE_WINDOW);


            /*
             * The rolling window uses:
             *
             *      failureTime > cutoff   -> still inside the window
             *      failureTime <= cutoff  -> expired
             *
             * Example with a 20-second window:
             *
             *      now    = 12:00:30
             *      cutoff = 12:00:10
             *
             *      failure at 12:00:09 -> expired
             *      failure at 12:00:10 -> expired
             *      failure at 12:00:11 -> counted
             *
             * The equality case is intentional: a failure exactly 20 seconds
             * old has reached the boundary and is no longer considered to be
             * "within the last 20 seconds".
             *
             * Because the deque is ordered oldest -> newest, once the front
             * timestamp is inside the window, every timestamp behind it must
             * also be inside the window. We can therefore stop immediately
             * instead of scanning the whole deque.
             */

            while (!failures.isEmpty() && !failures.peekFirst().isAfter(cutoff)) {
                failures.removeFirst();
            }
        }

    }

    /*
     * Simulates the supplied downstream call.
     */
    public Response call() {
        Random random = new Random();

        int rand = random.nextInt(2);

        Response response = new Response();

        int status = rand == 0 ? 200 : 500;

        response.setStatus(status);

        return response;
    }

    public static void main(String[] args) throws InterruptedException {

        // Clock clock = Clock.systemUTC();

        WebClient webClient = new WebClient();
        // WebClient webClient = new WebClient(clock);
        Random random = new Random();

        // Simulate continuous requests across two independent downstream services.
        for (int i = 0; i < 30; i++) {

            int rand = random.nextInt(2);
            String service = (rand == 0) ? "serviceB" : "serviceC";

            try {
                // Response response = webClient.execute(service);
                Request request = new Request(service);
                Response response = webClient.execute(request);

                System.out.println(Instant.now() + " -> " + service + " : " + response);
                // System.out.println(clock.instant() + " -> " + service + " : " + response);
            } catch (CircuitOpenException e) {

                System.out.println(Instant.now() + " -> " + service + " : " + e.getMessage());
                // System.out.println(clock.instant() + " -> " + service + " : " + e.getMessage());
            } catch (Exception e) {

                System.out.println(Instant.now() + " -> " + service + " : Unexpected exception - " + e.getMessage());
                // System.out.println(clock.instant() + " -> " + service + " : Unexpected exception - " + e.getMessage());
            }

            /*
             * Delay simulated requests so the rolling failure window and
             * cooldown can be observed during the demo.
             */
            Thread.sleep(2000);
        }
    }
}

