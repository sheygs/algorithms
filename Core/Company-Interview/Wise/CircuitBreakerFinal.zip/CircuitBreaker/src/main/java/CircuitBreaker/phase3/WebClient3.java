package CircuitBreaker.phase3;

import java.time.Clock;
import java.time.Duration;
import java.time.Instant;
import java.util.ArrayDeque;
import java.util.Deque;
import java.util.Map;
import java.util.Objects;
import java.util.Random;
import java.util.concurrent.ConcurrentHashMap;
import CircuitBreaker.CircuitOpenException;
import CircuitBreaker.Response;

class WebClient3 {

    /*
     * ============================================================
     * CIRCUIT-BREAKER CONFIGURATION
     * ============================================================
     */

    /*
     * Three qualifying failures inside the rolling window
     * open the circuit.
     */
    private static final int FAILURE_THRESHOLD = 3;


    /*
     * Only failures occurring inside the previous 20 seconds count.
     *
     * Active interval: (now - 20 seconds, now]
     *
     * Therefore a failure exactly 20 seconds old has expired.
     */
    private static final Duration FAILURE_WINDOW = Duration.ofSeconds(20);


    /*
     * Once OPEN, reject downstream calls for 10 seconds.
     */
    private static final Duration COOLDOWN = Duration.ofSeconds(10);


    /*
     * ============================================================
     * CACHE CONFIGURATION
     * ============================================================
     */

    /*
     * Successful responses remain usable for 30 seconds.
     */
    private static final Duration CACHE_TTL = Duration.ofSeconds(30);


    /*
     * ============================================================
     * DEPENDENCIES / STATE
     * ============================================================
     */

    /*
     * Clock is injected so rolling-window, cooldown and cache
     * boundaries can be tested deterministically.
     */
    private final Clock clock;


    /*
     * One independently synchronized circuit per downstream service.
     */
    private final Map<String, ServiceCircuit> circuits = new ConcurrentHashMap<>();


    /*
     * Stage 3 response cache.
     *
     * A cached value belongs to a particular service + request key.
     *
     * scope note: eviction is lazy (on next access to the
     * same key only). Long-running production use would need either
     * a bounded cache (e.g. Caffeine with maximumSize) or an active
     * TTL sweep to avoid unbounded growth from single-use keys.
     */
    private final Map<CacheKey, CachedResponse> cache = new ConcurrentHashMap<>();


    /*
     * ============================================================
     * CONSTRUCTORS
     * ============================================================
     */

    /**
     * Normal production-style constructor.
     */
    public WebClient3() {
        this(Clock.systemUTC());
    }


    /**
     * Constructor used when time needs to be controlled,
     * especially from tests.
     */
    public WebClient3(Clock clock) {
        this.clock = Objects.requireNonNull(clock, "clock must not be null");
    }


    /*
     * ============================================================
     * EXECUTE
     * ============================================================
     */

    /**
     * Executes a downstream request protected by:
     *
     * 1. response cache
     * 2. circuit breaker
     *
     * Stage 3 responsibility:
     *
     * - look in the cache before touching the breaker
     * - use the Stage 2-style ServiceCircuit for breaker decisions
     * - call the downstream service outside any circuit lock
     * - cache only successful 200 responses
     *
     * @param service
     *      downstream service name, e.g. "ServiceB" or "ServiceC"
     *
     * @param requestKey
     *      identifies the particular request/result being cached,
     *      e.g. customerId, accountId, URL/path, etc.
     *
     * @return
     *      fresh cached response or
     *      downstream response
     *
     * @throws CircuitOpenException
     *      if the circuit is currently OPEN or another recovery
     *      probe is in flight
     */
    public Response execute(String service, String requestKey) {
        if (service == null || service.isBlank()) {
            throw new IllegalArgumentException("service name must be provided");
        }

        if (requestKey == null || requestKey.isBlank()) {
            throw new IllegalArgumentException("requestKey must be provided");
        }

        /*
         * ========================================================
         * PHASE 0: CACHE LOOKUP
         * ========================================================
         *
         * Stage 3 starts with the cache.
         *
         * A fresh cache hit returns immediately, so neither the
         * circuit breaker nor the downstream service is touched.
         */
        CacheKey cacheKey = new CacheKey(service, requestKey);

        Instant now = clock.instant();

        CachedResponse cached = cache.get(cacheKey);

        if (cached != null) {

            /*
             * Fresh while:
             *
             *      now < expiresAt
             *
             * At exactly expiresAt, the entry is expired.
             */
            if (now.isBefore(cached.expiresAt())) {
                return cached.response();
            }

            /*
             * Remove only the exact expired value we observed.
             *
             * Under concurrency, another thread may have replaced it
             * with a newer value after our cache.get().
             */
            cache.remove(cacheKey, cached);
        }


        /*
         * ========================================================
         * PHASE 1: GET CIRCUIT
         * ========================================================
         *
         * Each downstream service has independent breaker state.
         */
        ServiceCircuit circuit = circuits.computeIfAbsent(service, ignored -> new ServiceCircuit());


        /*
         * ========================================================
         * PHASE 2: CIRCUIT ADMISSION
         * ========================================================
         *
         * This is the same refactored responsibility used in Stage 2.
         *
         * execute() does NOT inspect state/openedAt/failures directly.
         * ServiceCircuit owns that state machine.
         */
        Admission admission = circuit.admit(clock.instant());

        if (admission == Admission.REJECTED) {
            // Circuit is OPEN during cooldown, or another HALF_OPEN
            // recovery probe is already in flight.
            throw new CircuitOpenException(service);
        }

        boolean recoveryProbe = admission == Admission.RECOVERY_PROBE;


        /*
         * ========================================================
         * PHASE 3: DOWNSTREAM CALL
         * ========================================================
         *
         * VERY IMPORTANT:
         *
         * ServiceCircuit.admit() has already released its lock.
         * Never hold the circuit lock during a remote/network call.
         */
        Response response = call();


        /*
         * Use the time at which the downstream result was observed,
         * not the earlier admission time.
         */
        Instant outcomeTime = clock.instant();


        /*
         * ========================================================
         * PHASE 4: UPDATE BREAKER + CACHE
         * ========================================================
         */
        if (response.getStatus() == 200) {

            /*
             * Circuit-breaker behaviour remains Stage 2 behaviour:
             *
             * - normal CLOSED 200 -> do not clear failure history
             * - successful HALF_OPEN probe -> reset to CLOSED
             */
            circuit.handleSuccessfulResponse(recoveryProbe);

            /*
             * Stage 3 addition:
             *
             * Only successful responses are cached.
             */
            putSuccessfulResponseInCache(
                    cacheKey,
                    response,
                    outcomeTime
            );
        }

        if (response.getStatus() == 500) {

            /*
             * Circuit-breaker behaviour remains encapsulated inside
             * ServiceCircuit exactly as in the refactored Stage 2.
             */
            circuit.handleFailure(recoveryProbe, outcomeTime);

            // Never cache a 500 response.

        }


        /*
         * The request that produces failure #3 still gets its real downstream 500 response.
         *
         * Future requests will fail fast while the circuit is OPEN,
         * unless they can be served from a fresh cache entry first.
         */
        return response;
    }


    /*
     * ============================================================
     * OPTIONAL BACKWARDS-COMPATIBLE METHOD
     * ============================================================
     */

    /**
     * Convenience overload matching the earlier-stage signature.
     *
     * The service name is also used as the request cache key.
     */
    public Response execute(String service) {
        return execute(service, service);
    }


    /*
     * ============================================================
     * CACHE HELPER
     * ============================================================
     */

    /**
     * Stores a successful response with its expiry timestamp.
     *
     * Caller guarantees that the response is a successful 200.
     */
    private void putSuccessfulResponseInCache(CacheKey cacheKey, Response response, Instant now) {

        Instant expiresAt = now.plus(CACHE_TTL);

        CachedResponse cachedResponse = new CachedResponse(response, expiresAt);

        cache.put(cacheKey, cachedResponse);
    }


    /*
     * ============================================================
     * CIRCUIT STATE
     * ============================================================
     */

    /**
     * Explicit circuit-breaker states.
     */
    private enum CircuitState {

        /*
         * Calls are allowed normally.
         */
        CLOSED,

        /*
         * Calls are rejected during cooldown.
         */
        OPEN,

        /*
         * Exactly one recovery request is currently testing the
         * downstream service.
         */
        HALF_OPEN
    }


    /**
     * Result of asking one ServiceCircuit whether a request may proceed.
     */
    private enum Admission {
        NORMAL,
        RECOVERY_PROBE,
        REJECTED
    }


    /*
     * ============================================================
     * PER-SERVICE CIRCUIT STATE
     * ============================================================
     */

    /**
     * State and behaviour belonging to ONE downstream service.
     *
     * This is intentionally structured like the refactored Stage 2:
     * execute() orchestrates, while ServiceCircuit owns its own state
     * transitions and failure-window bookkeeping.
     */
    private static final class ServiceCircuit {

        /*
         * Rolling failure timestamps ordered oldest -> newest.
         */
        private final Deque<Instant> failures = new ArrayDeque<>();


        /*
         * Every service starts CLOSED.
         */
        private CircuitState state = CircuitState.CLOSED;


        /*
         * Time of the most recent transition to OPEN.
         *
         * null before the circuit has opened or after recovery.
         */
        private Instant openedAt;


        /**
         * Atomically decides whether a request is admitted.
         *
         * The lock is held only for local state inspection/update.
         * The downstream call is never made from here.
         */
        private synchronized Admission admit(Instant now) {

            /*
             * Keep only failures that are still active in the
             * rolling 20-second window.
             */
            pruneExpiredFailures(now);


            /*
             * ----------------------------------------------------
             * OPEN
             * ----------------------------------------------------
             */
            if (state == CircuitState.OPEN) {

                Instant recoveryAllowedAt = openedAt.plus(COOLDOWN);

                /*
                 * Cooldown is still active -> fail fast.
                 */
                if (now.isBefore(recoveryAllowedAt)) {
                    return Admission.REJECTED;
                }

                /*
                 * Cooldown has finished.
                 *
                 * This request atomically becomes the ONE recovery
                 * probe by transitioning OPEN -> HALF_OPEN.
                 */
                state = CircuitState.HALF_OPEN;

                return Admission.RECOVERY_PROBE;
            }


            /*
             * ----------------------------------------------------
             * HALF_OPEN
             * ----------------------------------------------------
             *
             * Another request is already testing recovery.
             */
            else if (state == CircuitState.HALF_OPEN) {
                return Admission.REJECTED;
            }


            /*
             * CLOSED -> ordinary request is allowed.
             */
            return Admission.NORMAL;
        }


        /**
         * Handles a successful downstream response.
         */
        private synchronized void handleSuccessfulResponse(boolean recoveryProbe) {

            /*
             * A successful HALF_OPEN recovery probe proves that the
             * downstream has recovered.
             *
             * HALF_OPEN -> CLOSED
             */
            if (recoveryProbe) {
                reset();
                return;
            }


            /*
             * A normal 200 while operating normally does NOT clear
             * previous failure history.
             *
             * This preserves the Stage 2 rolling-failure semantics.
             */
        }


        /**
         * Handles a qualifying 500 downstream response.
         */
        private synchronized void handleFailure(boolean recoveryProbe, Instant outcomeTime) {

            /*
             * ----------------------------------------------------
             * FAILED HALF_OPEN RECOVERY PROBE
             * ----------------------------------------------------
             *
             * HALF_OPEN -> OPEN
             *
             * Restart cooldown from the probe failure time.
             */
            if (recoveryProbe) {

                block(outcomeTime);

                /*
                 * Start a fresh failure history after the failed
                 * recovery attempt.
                 */
                failures.clear();
                recordFailure(outcomeTime);

                return;
            }


            /*
             * A normal 500 is a qualifying failure.
             *
             * Some time may have passed during call(), so prune using
             * the actual response/failure time before recording it.
             */
            pruneExpiredFailures(outcomeTime);

            recordFailure(outcomeTime);


            /*
             * Multiple CLOSED requests may already be in flight.
             * Another request may therefore have opened the circuit
             * while this request was executing.
             *
             * Only perform CLOSED -> OPEN here.
             */
            if (state == CircuitState.CLOSED && hasReachedFailureThreshold()) {
                block(outcomeTime);
            }
        }


        /**
         * Successful recovery starts the circuit with clean state.
         */
        private void reset() {
            failures.clear();
            openedAt = null;
            state = CircuitState.CLOSED;
        }


        /**
         * Records one qualifying failure timestamp.
         */
        private void recordFailure(Instant failureTime) {
            failures.addLast(failureTime);
        }


        /**
         * True once the active rolling window contains enough failures
         * to open the circuit.
         */
        private boolean hasReachedFailureThreshold() {
            return failures.size() >= FAILURE_THRESHOLD;
        }


        /**
         * Transitions the circuit to OPEN and starts/restarts cooldown.
         */
        private void block(Instant failureTime) {
            state = CircuitState.OPEN;
            openedAt = failureTime;
        }


        /*
         * ========================================================
         * ROLLING-WINDOW CLEANUP
         * ========================================================
         */

        /**
         * Removes failures that are no longer inside the active
         * rolling failure window.
         *
         * Must be called while holding the ServiceCircuit lock.
         */
        private void pruneExpiredFailures(Instant now) {

            Instant cutoff = now.minus(FAILURE_WINDOW);

            /*
             * Remove:
             *
             *      failureTime <= cutoff
             *
             * Keep:
             *
             *      failureTime > cutoff
             *
             * Therefore a failure exactly 20 seconds old is expired.
             * Concurrent → don't assume timestamp insertion order
             */
            failures.removeIf(t -> !t.isAfter(cutoff));
        }
    }


    /*
     * ============================================================
     * CACHE KEY
     * ============================================================
     */

    /**
     * Identifies a particular cacheable request result.
     *
     * Example:
     *
     *      ("ServiceB", "account-123")
     *
     * is different from:
     *
     *      ("ServiceB", "account-456")
     */
    private record CacheKey(String service, String requestKey) {
    }


    /*
     * ============================================================
     * CACHED VALUE
     * ============================================================
     */

    /**
     * Stores a successful response and its expiry timestamp.
     */
    private record CachedResponse(Response response, Instant expiresAt) {
    }


    /**
     * Treat this as supplied/opaque code for the exercise.
     *
     * Circuit-breaker and caching behaviour belongs around it,
     * rather than inside it.
     */
    public Response call() {
        Random random = new Random();

        int rand = random.nextInt(2);

        Response response = new Response();

        int status = rand == 0 ? 200 : 500;

        response.setStatus(status);

        return response;
    }


    /**
     * Demo only.
     *
     * Thread.sleep() spaces requests over time; it does not make this
     * loop concurrent. Concurrency behaviour should be verified in tests.
     */
    public static void main(String[] args) throws InterruptedException {

        WebClient3 webClient = new WebClient3();

        Random random = new Random();

        // Simulate continuous calls to ServiceB and ServiceC.
        for (int i = 0; i < 30; i++) {

            String requestKey = "request-" + i;

            int rand = random.nextInt(2);

            if (rand == 0) {
                webClient.execute("ServiceB", requestKey);
            } else {
                webClient.execute("ServiceC", requestKey);
            }

            Thread.sleep(2000);
        }
    }
}
