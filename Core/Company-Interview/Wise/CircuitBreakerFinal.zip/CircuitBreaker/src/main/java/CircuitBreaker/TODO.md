# To Do

1. Hard-coded static final thresholds/durations constants - FAILURE_THRESHOLD, FAILURE_WINDOW, COOLDOWN, CACHE_TTL - should be constructor-injected/per-dependency configurable.
